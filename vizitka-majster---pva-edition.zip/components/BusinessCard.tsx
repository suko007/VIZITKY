
import React from 'react';
import { CardData } from '../types';

interface BusinessCardProps {
  data: CardData;
  side: 'front' | 'back';
  motto?: string;
}

const BusinessCard: React.FC<BusinessCardProps> = ({ data, side, motto }) => {
  const cardStyle = {
    width: '90mm',
    height: '50mm',
    backgroundColor: '#ffffff',
    position: 'relative' as const,
    overflow: 'hidden',
    boxSizing: 'border-box' as const,
    display: 'block',
  };

  const LogoComponent = ({ className = "" }: { className?: string }) => (
    <div className={`flex items-center ${className}`}>
      {data.logoUrl ? (
        <img src={data.logoUrl} alt="Logo" className="h-10 object-contain" />
      ) : (
        <div className="font-black text-2xl tracking-tighter">
          <span style={{ color: data.primaryColor }}>PV</span>
          <span style={{ color: data.secondaryColor }}>A</span>
        </div>
      )}
    </div>
  );

  if (side === 'back') {
    return (
      <div style={cardStyle} className="flex flex-col items-center justify-center p-8 bg-white border border-gray-100">
        <div className="transform scale-[2] mb-6">
          <LogoComponent />
        </div>
        <div className="text-[10px] font-black tracking-[0.2em] uppercase text-gray-400">
          {data.company}
        </div>
        <div 
          className="absolute bottom-0 left-0 w-full h-2"
          style={{ backgroundColor: data.primaryColor }}
        ></div>
        <div 
          className="absolute top-0 right-0 w-24 h-24 bg-gray-50 rounded-full transform translate-x-12 -translate-y-12"
        ></div>
      </div>
    );
  }

  const renderTemplate = () => {
    switch (data.template) {
      case 'minimalist':
        return (
          <div className="h-full p-10 flex flex-col justify-between">
            <div className="flex justify-between items-start border-b pb-4 border-gray-100">
              <div>
                <LogoComponent />
                <p className="text-[8px] font-bold text-gray-400 uppercase mt-1 tracking-wider">{data.company}</p>
              </div>
              <div className="text-right">
                <h3 className="text-lg font-bold text-gray-900 leading-none">{data.name}</h3>
                <p className="text-[9px] text-gray-400 font-bold uppercase mt-1 tracking-widest">{data.title}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[8px] text-gray-600 pt-4">
              <p className="flex items-center gap-1.5"><i className="fas fa-phone opacity-50"></i> {data.phone}</p>
              <p className="flex items-center gap-1.5"><i className="fas fa-envelope opacity-50"></i> {data.email}</p>
              <p className="flex items-center gap-1.5"><i className="fas fa-globe opacity-50"></i> {data.website}</p>
              <p className="flex items-center gap-1.5"><i className="fas fa-map-marker-alt opacity-50"></i> {data.address}</p>
            </div>
          </div>
        );

      case 'sidebar':
        return (
          <div className="h-full flex">
            <div 
              className="w-[12mm] flex items-center justify-center py-4"
              style={{ backgroundColor: data.primaryColor }}
            >
              <div className="transform -rotate-90 whitespace-nowrap">
                <span className="text-white text-[10px] font-black tracking-widest uppercase">{data.company}</span>
              </div>
            </div>
            <div className="flex-1 p-8 flex flex-col justify-between">
              <div>
                <LogoComponent className="mb-4" />
                <h3 className="text-xl font-black text-gray-900 leading-tight">{data.name}</h3>
                <p className="text-[10px] font-bold" style={{ color: data.primaryColor }}>{data.title}</p>
              </div>
              <div className="space-y-1 text-[8px] text-gray-500 font-medium">
                <p className="flex items-center gap-2"><i className="fas fa-phone w-3 opacity-30"></i> {data.phone}</p>
                <p className="flex items-center gap-2"><i className="fas fa-envelope w-3 opacity-30"></i> {data.email}</p>
                <p className="flex items-center gap-2"><i className="fas fa-globe w-3 opacity-30"></i> {data.website}</p>
              </div>
            </div>
          </div>
        );

      case 'classic':
        return (
          <div className="h-full p-8 flex flex-col items-center justify-center text-center">
            <LogoComponent className="mb-2 scale-125" />
            <p className="text-[8px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4">{data.company}</p>
            <div className="mb-4">
              <h3 className="text-lg font-bold text-gray-900">{data.name}</h3>
              <p className="text-[9px] text-gray-400 uppercase tracking-widest font-bold">{data.title}</p>
            </div>
            <div className="w-10 h-0.5 mb-4" style={{ backgroundColor: data.primaryColor }}></div>
            <div className="space-y-1 text-[8.5px] text-gray-600">
              <p>{data.phone} | {data.email}</p>
              <p>{data.address}</p>
            </div>
          </div>
        );

      case 'modern':
      default:
        return (
          <div className="h-full relative bg-white">
            <div 
              className="absolute top-0 right-0 w-32 h-full opacity-[0.03] pointer-events-none"
              style={{ backgroundColor: data.primaryColor, clipPath: 'polygon(100% 0, 0 0, 100% 100%)' }}
            ></div>
            
            <div className="p-10 h-full flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div>
                  <LogoComponent />
                  <p className="text-[8px] font-black text-gray-400 uppercase mt-1 tracking-wider">{data.company}</p>
                </div>
                <div className="text-right">
                  <h3 className="text-xl font-black text-gray-900 leading-none">{data.name}</h3>
                  <p className="text-[10px] font-bold mt-1 tracking-wide" style={{ color: data.primaryColor }}>{data.title}</p>
                </div>
              </div>

              {motto && (
                <div className="italic text-[9px] text-gray-400 mt-2 border-l-2 pl-2" style={{ borderColor: data.primaryColor }}>
                  "{motto}"
                </div>
              )}

              <div className="flex justify-between items-end">
                <div className="space-y-1.5 text-[8.5px] text-gray-700 font-semibold">
                  <div className="flex items-center gap-2">
                    <i className="fas fa-phone text-[7px]" style={{ color: data.primaryColor }}></i>
                    {data.phone}
                  </div>
                  <div className="flex items-center gap-2">
                    <i className="fas fa-envelope text-[7px]" style={{ color: data.primaryColor }}></i>
                    {data.email}
                  </div>
                </div>

                <div className="text-right text-[8px] text-gray-400">
                  <p className="font-black" style={{ color: data.secondaryColor }}>{data.website}</p>
                  <p className="max-w-[140px] leading-tight">{data.address}</p>
                </div>
              </div>
            </div>
            <div 
              className="absolute bottom-0 left-0 w-full h-1"
              style={{ 
                background: `linear-gradient(to right, ${data.primaryColor}, ${data.secondaryColor})` 
              }}
            ></div>
          </div>
        );
    }
  };

  return (
    <div style={cardStyle} className="border border-gray-100">
      {renderTemplate()}
    </div>
  );
};

export default BusinessCard;
